package com.example.alexr.cst2335_lab3;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class ChatWindow extends AppCompatActivity {

    ListView chatListView;
    EditText chatMessageEditText;
    Button chatSendBtn;

    ArrayList<String> chatMessages = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_window);

        chatListView = (ListView)findViewById(R.id.chatListView);
        chatMessageEditText = (EditText)findViewById(R.id.chatMessageEditText);
        chatSendBtn = (Button)findViewById(R.id.chatSendBtn);

        //in this case, "this" is the ChatWindow, which is-A Context object
        ChatAdapter messageAdapter = new ChatAdapter( this );
        chatListView.setAdapter(messageAdapter);


        chatSendBtn.setOnClickListener(
                (View v) -> {
                    chatMessages.add(chatMessageEditText.getText().toString());
                    messageAdapter.notifyDataSetChanged(); //this restarts the process of getCount()/getView()
                    chatMessageEditText.setText("");
                });

    }

    public class ChatAdapter extends ArrayAdapter<String>{
        public ChatAdapter(Context context){
            super(context, 0);
        }
        @Override
        public int getCount(){
            return chatMessages.size();
        }

        @Override
        public String getItem(int position){
            return chatMessages.get(position);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent){

            LayoutInflater inflater = ChatWindow.this.getLayoutInflater();

            View result = null;
            if( position % 2 == 0 ){
                result = inflater.inflate(R.layout.chat_row_outgoing, null);
            }else{
                result = inflater.inflate(R.layout.chat_row_incoming, null);
            }

            TextView message = (TextView)result.findViewById(R.id.message_text);
            message.setText( getItem(position) );
            return result;

        }


    }
}
